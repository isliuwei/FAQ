package com.fit.entity;

import android.provider.BaseColumns;

public interface Memo extends BaseColumns{

	public static final String DBNAME="dbMemo";
	public static final String TABLENAME="memo";
	public static final String LTIME="ltime";
	public static final String CONTENT="content";
	
}
