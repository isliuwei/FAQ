package com.androidbook.simpletelephony;

public class SimpleTelephonyActivity extends MenuActivity {
    public void prepareMenu() {
        addMenuItem("1 发送短信", SendSMSActivity.class);
        addMenuItem("2 拨打电话", MakeCallActivity.class);
    }
}