package com.androidbook.shapeshifter;


public class ShapeShifterActivity extends MenuActivity {
  
    @Override
    void prepareMenu() {
        addMenuItem("Tweened Animation", TweenActivity.class);
        
    }
    
    
}